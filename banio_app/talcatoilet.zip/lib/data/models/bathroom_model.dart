import '../../domain/entities/bathroom.dart';

class BathroomModel extends Bathroom {
  BathroomModel({
    required int id,
    required double lat,
    required double lon,
    required Map<String, dynamic> tags,
  }) : super(id: id, lat: lat, lon: lon, tags: tags);

  factory BathroomModel.fromJson(Map<String, dynamic> json) {
    double lat, lon;

    if (json.containsKey('center')) {
      lat = json['center']['lat'];
      lon = json['center']['lon'];
    } else {
      lat = json['lat'] ?? 0.0;
      lon = json['lon'] ?? 0.0;
    }

    return BathroomModel(
      id: json['id'],
      lat: lat,
      lon: lon,
      tags: json['tags'] ?? {},
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'lat': lat,
    'lon': lon,
    'name': tags['name'] ?? '',
    'fee': tags['fee'] ?? '',
    'wheelchair': tags['toilets:wheelchair'] ?? '',
    'tags': tags,
    'ratingAvg': 0.0,
    'ratingCount': 0,
    'source': 'osm_or_mock',
    'updatedAt': DateTime.now(),
  };
}
